﻿using System;
using System.Collections.Generic;

class Person
{
    public int personId;
    public string firstName;
    public string lastName;
    public string favoriteColour;
    public int age;
    public bool isWorking;

    public void DisplayPersonInfo()
    {
        Console.WriteLine($"PersonId: {personId}\nName: {firstName} {lastName}'s favorite colour is {favoriteColour}\n");
    }

    public void ChangeFavoriteColour()
    {
        favoriteColour = "White";
        Console.WriteLine($"{firstName} {lastName}'s favorite colour is: {favoriteColour}\n");
    }

    public int GetAgeInTenYears()
    {
        return age + 10;
    }

    public override string ToString()
    {
        return $"PersonId: {personId}\nFirstName: {firstName}\nLastName: {lastName}\nFavoriteColour: {favoriteColour}\nAge: {age}\nIsWorking: {isWorking}\n";
    }
}

class Relation
{
    public enum RelationshipType
    {
        Sister,
        Brother,
        Mother,
        Father
    }

    public RelationshipType relationshipType;

    public void ShowRelationShip(Person person1, Person person2)
    {
        Console.WriteLine($"Relationship between {person1.firstName} and {person2.firstName} is: {relationshipType}hood\n");
    }
}

class MainClass
{
    public static void Main(string[] args)
    {
        // Creating Person objects
        Person person1 = new Person { personId = 1, firstName = "Ian", lastName = "Brooks", favoriteColour = "Red", age = 30, isWorking = true };
        Person person2 = new Person { personId = 2, firstName = "Gina", lastName = "James", favoriteColour = "Green", age = 18, isWorking = false };
        Person person3 = new Person { personId = 3, firstName = "Mike", lastName = "Briscoe", favoriteColour = "Blue", age = 45, isWorking = true };
        Person person4 = new Person { personId = 4, firstName = "Mary", lastName = "Beals", favoriteColour = "Yellow", age = 28, isWorking = true };

        // Display Gina’s information
        Console.WriteLine($"{person2.personId}: {person2.firstName} {person2.lastName}'s favorite colour is {person2.favoriteColour}\n");

        // Display all of Mike’s information as a list
        Console.WriteLine(person3.ToString());

        // Change Ian’s Favorite Colour to white
        person1.ChangeFavoriteColour();

        // Display Mary’s age after ten years
        Console.WriteLine($"{person4.firstName} {person4.lastName}'s Age in 10 years is: {person4.GetAgeInTenYears()}\n");

        // Create two Relation Objects
        Relation relation1 = new Relation { relationshipType = Relation.RelationshipType.Sister };
        Relation relation2 = new Relation { relationshipType = Relation.RelationshipType.Brother };

        // Display both relationships
        relation1.ShowRelationShip(person2, person4);
        relation2.ShowRelationShip(person1, person3);

        // Add all the Person objects to a list
        List<Person> peopleList = new List<Person> { person1, person2, person3, person4 };

        // Calculate and display average age
        int totalAge = 0;
        foreach (var person in peopleList)
        {
            totalAge += person.age;
        }
        double averageAge = totalAge / (double)peopleList.Count;
        Console.WriteLine($"Average age is: {averageAge}");

        // Find and display the youngest person and the oldest person
        int minAge = int.MaxValue;
        int maxAge = int.MinValue;
        Person youngestPerson = null;
        Person oldestPerson = null;

        foreach (var person in peopleList)
        {
            if (person.age < minAge)
            {
                minAge = person.age;
                youngestPerson = person;
            }

            if (person.age > maxAge)
            {
                maxAge = person.age;
                oldestPerson = person;
            }
        }

        Console.WriteLine($"The youngest person is: {youngestPerson.firstName}");
        Console.WriteLine($"The oldest person is: {oldestPerson.firstName}");

        // Display the names of the people whose first names start with M
        Console.WriteLine("People whose first names start with M:");
        foreach (var person in peopleList)
        {
            if (person.firstName.StartsWith("M"))
            {
                Console.WriteLine(person.ToString());
            }
        }
    }
}
